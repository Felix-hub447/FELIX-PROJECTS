jQuery(document).ready(function(jQuery) {
    var window_w = jQuery(window).width(),
        mobile_devices = detectMobileBrowser(),
        ie_version = detectIE();

    if (window_w >= 980) {
        if (mobile_devices) {
            // first level
            jQuery('.dropdown > a').bind("tap", detectTap);

            // deeper levels
            jQuery('.dropdown-submenu > a').bind("tap", detectTap);

            // deeper levels
            jQuery('.rstpl-mega-menu > a').bind("tap", detectTap);

            jQuery('body').bind("tap", closeDropdowns);
        }
    }

    jQuery(window).resize(function() {
        window_w = jQuery(window).width();

        if (window_w >= 980) {
            if (mobile_devices) {
                // first level
                jQuery('.dropdown > a').bind("tap", detectTap);

                // deeper levels
                jQuery('.dropdown-submenu > a').bind("tap", detectTap);

                // deeper levels
                jQuery('.rstpl-mega-menu > a').bind("tap", detectTap);

                jQuery('body').bind("tap", closeDropdowns);
            } else {
                // first level
                jQuery('.dropdown > a').unbind("tap", detectTap);

                // deeper levels
                jQuery('.dropdown-submenu > a').unbind("tap", detectTap);

                // deeper levels
                jQuery('.rstpl-mega-menu > a').unbind("tap", detectTap);

                jQuery('body').unbind("tap", closeDropdowns);
            }
        }
    });
});

function detectMobileBrowser() {
    if (/Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        return true;
    } else {
        return false;
    }
}

function detectIE() {
    var ua = window.navigator.userAgent;

    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        // IE 10 or older
        return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }

    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
        // IE 11
        var rv = ua.indexOf('rv:');
        return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
    }

    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
        // Edge (IE 12+)
        return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    }

    // other browser
    return false;
}

function detectTap(event) {
    var clickedElement = jQuery(event.target);
    var parentElement = jQuery(clickedElement.parent());
    var dropdown = parentElement.find('.dropdown-menu').first();
    var megadrop = parentElement.find('.rstpl-mega-menu-container').first();
    var isLink = clickedElement.attr('href');

    // close other opened dropdowns
    if (isLink) {
        if (parentElement.hasClass('dropdown') || parentElement.hasClass('rstpl-mega-menu')) {
            jQuery('.dropdown').each(function() {
                var dropdown = jQuery(this).find('.dropdown-menu').first();

                if (dropdown.css('visibility') == 'visible' && parentElement.attr('class') !== dropdown.parent().attr('class') && dropdown.parent().hasClass('current')) {
                    dropdown.css('visibility', 'hidden');
                    dropdown.css('opacity', '0');
                } else if (dropdown.css('visibility') == 'visible' && parentElement.attr('class') !== dropdown.parent().attr('class')) {
                    dropdown.parent().removeClass('active');
                    dropdown.css('visibility', 'hidden');
                    dropdown.css('opacity', '0');
                }
            });
            jQuery('.rstpl-mega-menu').each(function() {
                var megadrop = jQuery(this).find('.rstpl-mega-menu-container').first();

                if (megadrop.css('visibility') == 'visible' && parentElement.attr('class') !== megadrop.parent().attr('class') && megadrop.parent().hasClass('current')) {
                    megadrop.css('visibility', 'hidden');
                    megadrop.css('opacity', '0');
                } else if (megadrop.css('visibility') == 'visible' && parentElement.attr('class') !== megadrop.parent().attr('class')) {
                    megadrop.parent().removeClass('active');
                    megadrop.css('visibility', 'hidden');
                    megadrop.css('opacity', '0');
                }
            });
        }
    }

    // first tap -> open dropdown and second tap -> open dropdown parent url
    if ((parentElement.hasClass('dropdown') && parentElement.hasClass('active') && dropdown.css('visibility') == 'visible') || (parentElement.hasClass('dropdown-submenu') && parentElement.hasClass('active') && dropdown.css('visibility') == 'visible') || (parentElement.hasClass('rstpl-mega-menu') && parentElement.hasClass('active') && megadrop.css('visibility') == 'visible')) {
        return true;
    } else if (parentElement.hasClass('dropdown') || parentElement.hasClass('dropdown-submenu')) {
        parentElement.addClass('active');
        parentElement.find('.dropdown-menu').first().css('visibility', 'visible');
        parentElement.find('.dropdown-menu').first().css('opacity', '1');
        return false;
    } else if (parentElement.hasClass('rstpl-mega-menu')) {
        parentElement.addClass('active');
        parentElement.find('.rstpl-mega-menu-container').first().css('visibility', 'visible');
        parentElement.find('.rstpl-mega-menu-container').first().css('opacity', '1');
        return false;
    }

    return false;
}

function closeDropdowns(event) {
    var clickedElement = jQuery(event.target);
    var parentElement = clickedElement.parent();
    var isLink = clickedElement.attr('href');

    // close dropdowns when the tap is outside the menu
    if (!isLink) {
        if (!parentElement.hasClass('dropdown') || !parentElement.hasClass('dropdown-submenu') || !parentElement.hasClass('rstpl-mega-menu')) {
            jQuery('.dropdown').each(function() {
                var dropdown = jQuery(this).find('.dropdown-menu').first();

                if (dropdown.css('visibility') == 'visible' && dropdown.parent().hasClass('current')) {
                    dropdown.css('visibility', 'hidden');
                    dropdown.css('opacity', '0');
                } else if (dropdown.css('visibility') == 'visible') {
                    dropdown.parent().removeClass('active');
                    dropdown.css('visibility', 'hidden');
                    dropdown.css('opacity', '0');
                }
            });
            jQuery('.rstpl-mega-menu').each(function() {
                var megadrop = jQuery(this).find('.rstpl-mega-menu-container').first();

                if (megadrop.css('visibility') == 'visible' && megadrop.parent().hasClass('current')) {
                    megadrop.css('visibility', 'hidden');
                    megadrop.css('opacity', '0');
                } else if (megadrop.css('visibility') == 'visible') {
                    megadrop.parent().removeClass('active');
                    megadrop.css('visibility', 'hidden');
                    megadrop.css('opacity', '0');
                }
            });
        }
    }
}