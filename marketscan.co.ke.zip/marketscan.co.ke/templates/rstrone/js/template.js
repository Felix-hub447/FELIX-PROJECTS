/*
 * @version       1.0.0
 * @package       RSTrone! 1.0.0
 * @copyright (C) 2018 www.rsjoomla.com
 * @license       GNU General Public License http://www.gnu.org/licenses/gpl-3.0.en.html
 */

! function(jQuery) {
    jQuery(document).ready(function() {

        // Turn radios into btn-group
        RSTemplate.transformBtnGroup();

        // Fix for Bootstrap collapse (accordion)
        RSTemplate.fixAccordions();

        // Fix for Bootstrap carousel slide
        RSTemplate.fixCarousels();

        // IE specific fixes
        RSTemplate.fixIE();

        // Fade-in alerts
        RSTemplate.fadeInAlerts();

        // OnePage website
        if (RSTemplate.onePageCheck()) {
            RSTemplate.initOnePage();
        }

        // Search from
        RSTemplate.initSearchForm();

        // Login form
        RSTemplate.initLoginForm();

        // Initialize navbar button
        RSTemplate.initNavbarButton();

        // Animate navbar button
        RSTemplate.animateNavbarButton();

        // Fill text
        RSTemplate.initFillText();

        // Bold title word
        RSTemplate.initBoldTitleWord();

        // Tooltip
        RSTemplate.initTooltip();

        // Go to top button
        RSTemplate.initGoToTop();

        // Masonry
        RSTemplate.initMasonry();

        // Preloader
        RSTemplate.initPreloader(jQuery('.animsition'), jQuery('.animsition').attr('data-animsition-in-class'), jQuery('.animsition').attr('data-animsition-out-class'), jQuery('.animsition').attr('data-animsition-loading-class'));
    });

    jQuery(window).ready(function() {
        // Fade content
        if (RSTemplate.hasContentFader()) {
            RSTemplate.fadeContent();
        }
    });
}(window.jQuery);

var RSTemplate;
RSTemplate = {
    onePageCheck: function() {
        var $menu = jQuery('.rstpl-main-menu-position');
        if (typeof $menu != 'undefined') {
            var $links = $menu.find('.rstpl-template-menu > li:not(.active) > a'),
                $continue = true;

            $links.each(function() {
                if (!(jQuery(this).hasClass('open-login') || jQuery(this).hasClass('open-search'))) {
                    var $href = jQuery(this).attr('href');
                    if ($href.charAt(0) !== '#') {
                        $continue = false;
                    }
                }
            });

            if ($menu.attr('data-onepage') == 'true' && $continue) {
                return true;
            }
        }
        return false;
    },
    initOnePage: function() {
        var $menu = jQuery('.rstpl-main-menu-position');
        if (typeof $menu != 'undefined') {
            $menu.find('.rstpl-template-menu > .active > a').attr('href', '#rstpl-main-menu-position');

            $menu.find('.rstpl-template-menu').onePageNav({
                currentClass: 'active',
                changeHash: true,
                scrollSpeed: 750,
                scrollThreshold: 0.5,
                filter: '',
                easing: 'swing'
            });
        }
    },
    initMasonry: function() {
        try {
            jQuery('.rstpl-masonry-container').masonry({
                itemSelector: '.rstpl-masonry'
            });
        } catch (error) {}
    },
    fadeContent: function() {
        try {
            window.sr = new scrollReveal({
                vFactor: 0.60,
                move: '30px',
                scale: {
                    direction: 'up',
                    power: '0%'
                },
                over: '1s',
                ease: 'hustle'
            });
        } catch (error) {}
    },
    hasContentFader: function() {
        return (typeof scrollReveal != 'undefined');
    },
    initPreloader: function(selector, in_class, out_class, loading_class) {
        if (selector.length) {
            selector.animsition({
                inClass: in_class,
                outClass: out_class,
                inDuration: 1500,
                outDuration: 1000,
                linkElement: 'a[href$="ABC"] a:not([target="_blank"]):not([href="javascript:void(0)"]):not([href^="#"]):not(".rsmg_lightbox"):not(".magnific-popup"):not(".comment-reply-link"):not(".collapsed"):not(".modal")',
                loading: true,
                loadingParentElement: 'body', //animsition wrapper element
                loadingClass: loading_class,
                unSupportCss: [
                    'animation-duration',
                    '-webkit-animation-duration',
                    '-o-animation-duration'
                ],
                overlay: false,
                overlayClass: 'animsition-overlay-slide',
                overlayParentElement: 'body'
            });
        }

        // Add HTML elements to loader when necessary
        if (loading_class == 'animsition-square-bullets-loading') {
            for (var i = 1; i <= 4; i++) {
                jQuery('<span></span>').appendTo('.animsition-square-bullets-loading');
            }
        } else if (loading_class == 'animsition-circle-sectors-loading') {
            for (var i = 1; i <= 8; i++) {
                jQuery('<span></span>').appendTo('.animsition-circle-sectors-loading');
            }
        } else if (loading_class == 'animsition-wave-bullets-loading') {
            for (var i = 1; i <= 5; i++) {
                jQuery('<span></span>').appendTo('.animsition-wave-bullets-loading');
            }
        } else if (loading_class == 'animsition-pulse-squares-loading') {
            for (var i = 1; i <= 4; i++) {
                jQuery('<span></span>').appendTo('.animsition-pulse-squares-loading');
            }
        } else if (loading_class == 'animsition-grow-bullets-loading') {
            for (var i = 1; i <= 4; i++) {
                jQuery('<span></span>').appendTo('.animsition-grow-bullets-loading');
            }
        } else if (loading_class == 'animsition-slide-bullets-loading') {
            for (var i = 1; i <= 6; i++) {
                jQuery('<span></span>').appendTo('.animsition-slide-bullets-loading');
            }
        }
    },
    transformBtnGroup: function() {
        jQuery('.radio.btn-group label').addClass('btn');
        jQuery('.btn-group label:not(.active)').click(function() {
            var label = jQuery(this);
            var input = jQuery('#' + label.attr('for'));

            if (!input.prop('checked')) {
                label.closest('.btn-group').find('label').removeClass('active btn-success btn-danger btn-primary');
                if (input.val() == '') {
                    label.addClass('active btn-primary');
                } else if (input.val() == 0) {
                    label.addClass('active btn-danger');
                } else {
                    label.addClass('active btn-success');
                }
                input.prop('checked', true);
            }
        });
        jQuery('.btn-group input[checked=checked]').each(function() {
            if (jQuery(this).val() == '') {
                jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-primary');
            } else if (jQuery(this).val() == 0) {
                jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-danger');
            } else {
                jQuery('label[for=' + jQuery(this).attr('id') + ']').addClass('active btn-success');
            }
        });
    },
    fadeInAlerts: function() {
        window.setTimeout(function() {
            jQuery('.alert').addClass('in');
        }, 400);
    },
    fixAccordions: function() {
        jQuery('.accordion').each(function() {
            jQuery(this).find('.accordion-toggle').each(function(i, title) {
                if (jQuery(title).parent().siblings('.accordion-body').hasClass('in') === false)
                    jQuery(title).addClass('collapsed');
            });
        });
        jQuery('.accordion-toggle').click(function() {
            jQuery(this).parents('.accordion').each(function() {
                jQuery(this).find('.accordion-toggle').each(function(i, title) {
                    jQuery(title).addClass('collapsed');
                });
            });
        });
    },
    fixCarousels: function() {
        // add reset if function does not exist in Carousel
        if (jQuery.fn.carousel.Constructor.prototype.reset == undefined) {
            jQuery.fn.carousel.Constructor.prototype.reset = function() {
                this.sliding = false;
            }
        }
    },
    initFillText: function() {
        if (jQuery('body').hasClass('site')) {
            jQuery.each(jQuery('.rstpl-navigation .rstpl-template-menu > li > a'), function() {
                jQuery(this).fillText();
            });
        }
    },
    initBoldTitleWord: function() {
        jQuery('.bold-first-word .rspbld-row-title, .bold-first-word .rspbld-column-title, .bold-first-word .rspbld-title, .bold-first-word.rstpl-title').html(function() {
            var text = jQuery(this).text().trim().split(' '),
                first_word = text.shift();

            return (text.length > 0 ? '<span class="bold">' + first_word + '</span> ' : first_word) + text.join(' ');
        });
        jQuery('.bold-last-word .rspbld-row-title, .bold-last-word .rspbld-column-title, .bold-last-word .rspbld-title, .bold-last-word.rstpl-title').html(function() {
            var text = jQuery(this).text().trim().split(' '),
                last_word = text.pop();

            return text.join(' ') + (text.length > 0 ? ' <span class="bold">' + last_word + '</span>' : last_word);
        });
    },
    initTooltip: function() {
        jQuery('*[rel=tooltip]').tooltip();
        jQuery('*[data-toggle=tooltip]').tooltip();
        jQuery('*[class=hasTooltip]').tooltip();
    },
    initGoToTop: function() {
        var back_to_top = jQuery('.rstpl-go-top');

        jQuery(window).scroll(function() {
            (jQuery(this).scrollTop() > 300) ? back_to_top.addClass('rstpl-go-top-is-visible'): back_to_top.removeClass('rstpl-go-top-is-visible rstpl-go-top-fade-out');
            if (jQuery(this).scrollTop() > 1200) {
                back_to_top.addClass('rstpl-go-top-fade-out');
            }
        });

        back_to_top.on('click', function(event) {
            event.preventDefault();
            jQuery('body,html').animate({
                scrollTop: 0
            }, 700);
        });
    },
    fixIE: function() {
        // Placeholder fix for IE9
        if (jQuery.browser.msie && (jQuery.browser.version == '9.0')) {
            jQuery('input, textarea').placeholder();
        }

        // Last-child fix for IE8
        if (jQuery.browser.msie && parseInt(jQuery.browser.version, 10) <= 8) {
            jQuery('.dropdown-submenu > .dropdown-menu li:last-child').addClass('last-child');
            jQuery('.rstpl-box-pricing .table tr:last-child').addClass('last-child');
        }
    },
    animateNavbarButton: function() {
        jQuery('.rstpl-main-menu-position .btn-navbar').click(function() {
            jQuery('.first-bar').toggleClass('left-bar');
            jQuery('.second-bar').toggleClass('right-bar');
            jQuery('.third-bar').toggleClass('bottom-bar');
        });
    },
    initNavbarButton: function() {
        // Add the icon
        var menu_items = jQuery('.rstpl-main-menu-position .rstpl-template-menu > li');

        menu_items.each(function() {
            var icon = jQuery(this).attr('data-icon');

            if (typeof icon != 'undefined') {
                jQuery(this).children('a').prepend('<span class="menu-icon ' + icon + '"></span>');
            }
        });

        // we initiate a submenu button as well here
        jQuery('.parent').append('<span class="submenu-button"></span>');

        var mega_menu = jQuery('.rstpl-mega-menu');

        mega_menu.each(function() {
            var mega_menu_children = jQuery(this).children('.rstpl-mega-menu-container').not('.visible-desktop');

            if (mega_menu_children.length) {
                jQuery(this).append('<span class="submenu-button"></span>');
            }
        });


        // on clicking the submenu-button, open the dropdown menu
        jQuery('.submenu-button').click(function() {
            jQuery(this).toggleClass('opened');
            jQuery(this).siblings('.dropdown-menu, .rstpl-mega-menu-container').slideToggle('fast');
        });

        // fix for sub-menu items that are visible outside viewport
        if (jQuery.isFunction(jQuery.fn.offscreen)) {
            jQuery('.dropdown-menu').offscreen({
                rightClass: 'right-edge',
                leftClass: 'left-edge',
                smartResize: true
            });
        }

        /**
         * If you closed the menu through the sub-menu button, the dropdown would have "display:none"
         * This would prevent it to open through hover if you resized the window
         * so upon resizing, we remove the attribute (usable for devices such as landscape tablets)
         */
        jQuery(window).resize(function() {
            window_w = jQuery(window).width();

            if (window_w > 768) {
                jQuery('.rstpl-template-menu').find('.dropdown-menu').each(function() {
                    jQuery(this).removeAttr('style');
                });
            }
        });
    },
    initSearchForm: function() {
        var search_input = jQuery('.rstpl-navbar-search .search-bar, .rstpl-navbar-search .search-query, .rstpl-navbar-search .k2SearchBlock .inputbox'),
            search_open = jQuery('.rstpl-navbar-search .open-search');

        search_open.click(function(e) {
            e.preventDefault();
            jQuery(this).toggleClass('active').find('i').toggleClass('icon-times');
            search_input.toggleClass('open');
        });
    },
    initLoginForm: function() {
        var login_form = jQuery('.rstpl-navbar-login > form'),
            login_open = jQuery('.rstpl-navbar-login .open-login');

        login_open.click(function(e) {
            e.preventDefault();
            jQuery(this).parent().toggleClass('active');
            login_form.toggleClass('open');
        });
    }
};

(function($) {
    $(document).ready(function() {

        // jQuery reverse
        $.fn.reverse = [].reverse;

        $(document).on('click', '.fixed-action-btn', function(e) {
            var $this = $(this);
            if ($(this).hasClass('active')) {
                closeFABMenu($this);
            } else {
                openFABMenu($this);
            }
        });

    });

    $.fn.extend({
        openFAB: function() {
            var $this = $(this);
            openFABMenu($this);
        },
        closeFAB: function() {
            var $this = $(this);
            closeFABMenu($this);
        }
    });


    var openFABMenu = function(btn) {
        $this = btn;
        if ($this.hasClass('active') === false) {
            $this.addClass('active');
            $this.find('ul').css('display', 'block');
            $this.find('ul .btn-floating').velocity({
                scaleY: ".4",
                scaleX: ".4",
                translateY: "40px"
            }, {
                duration: 0
            });

            var time = 0;
            $this.find('ul .btn-floating').reverse().each(function() {
                $(this).velocity({
                    opacity: "1",
                    scaleX: "1",
                    scaleY: "1",
                    translateY: "0"
                }, {
                    duration: 80,
                    delay: time
                });
                time += 40;
            });
        }
    };

    var closeFABMenu = function(btn) {
        $this = btn;
        $this.removeClass('active');
        var time = 0;
        $this.find('ul .btn-floating').velocity("stop", true);
        $this.find('ul .btn-floating').velocity({
            opacity: "0",
            scaleX: ".4",
            scaleY: ".4",
            translateY: "40px"
        }, {
            duration: 80
        });
        setTimeout(function() {
            $this.find('ul').css('display', 'none');
        }, 600);
    };

}(jQuery));