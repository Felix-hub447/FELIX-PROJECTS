jQuery.fn.fillText = function(options) {
    var defaults = {
            element_class: 'fill-text'
        },
        current_item = jQuery(this),
        current_item_text = current_item.text();

    jQuery.extend(defaults, options);

    if ((!current_item.next('.' + defaults.element_class).length) && (!current_item.hasClass('open-search')) && (!current_item.parent().parent().closest('li').hasClass('rstpl-mega-menu'))) {
        current_item.addClass(defaults.element_class);
        current_item.attr('data-fill', current_item.text());
    }
}