import * as yup from 'yup';

export const productPurchasesValidationSchema = yup.object().shape({});
