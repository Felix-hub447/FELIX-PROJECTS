import * as yup from 'yup';

export const customerDetailsValidationSchema = yup.object().shape({});
