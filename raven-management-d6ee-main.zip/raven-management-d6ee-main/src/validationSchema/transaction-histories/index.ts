import * as yup from 'yup';

export const transactionHistoryValidationSchema = yup.object().shape({});
