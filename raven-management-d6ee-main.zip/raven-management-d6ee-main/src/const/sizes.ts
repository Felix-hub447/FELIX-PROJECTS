export const HEADER_MD_HEIGHT = '72px';
export const HEADER_MOBILE_HEIGHT = '216px';
