export type { GetQueryInterface } from './get-query.interface';
export type { GetManyQueryOptions } from './get-many-query.interface';
export type { PaginatedInterface } from './paginated.interface';
