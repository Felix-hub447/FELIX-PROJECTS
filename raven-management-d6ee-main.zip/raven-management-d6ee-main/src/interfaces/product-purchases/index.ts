import { GetQueryInterface } from 'interfaces';

export interface ProductPurchasesInterface {
  id?: string;
  created_at?: any;
  updated_at?: any;

  _count?: {};
}

export interface ProductPurchasesGetQueryInterface extends GetQueryInterface {
  id?: string;
}
