export interface PaginatedInterface<T> {
  data: T[];
  totalCount: number;
}
