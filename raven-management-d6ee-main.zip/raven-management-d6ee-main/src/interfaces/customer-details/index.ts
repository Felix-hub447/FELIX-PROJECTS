import { GetQueryInterface } from 'interfaces';

export interface CustomerDetailsInterface {
  id?: string;
  created_at?: any;
  updated_at?: any;

  _count?: {};
}

export interface CustomerDetailsGetQueryInterface extends GetQueryInterface {
  id?: string;
}
