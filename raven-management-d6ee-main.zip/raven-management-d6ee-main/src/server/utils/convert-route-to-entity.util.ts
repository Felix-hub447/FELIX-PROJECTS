const mapping: Record<string, string> = {
  companies: 'company',
  'customer-details': 'customer_details',
  'product-purchases': 'product_purchases',
  'transaction-histories': 'transaction_history',
  users: 'user',
};

export function convertRouteToEntityUtil(route: string) {
  return mapping[route] || route;
}
