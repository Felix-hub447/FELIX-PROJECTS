export enum FileCategories {
  userFiles = 'USER_FILES',
}
