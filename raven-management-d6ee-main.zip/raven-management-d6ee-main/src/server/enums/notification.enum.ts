export enum NotificationTypes {
  welcome = 'welcome',
}
