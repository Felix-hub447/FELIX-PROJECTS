export interface FilesFetchDto {
  limit?: number;
  offset?: number;
}
