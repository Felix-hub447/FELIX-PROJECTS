interface AppConfigInterface {
  ownerRoles: string[];
  customerRoles: string[];
  tenantRoles: string[];
  tenantName: string;
  applicationName: string;
  addOns: string[];
  ownerAbilities: string[];
  customerAbilities: string[];
  getQuoteUrl: string;
}
export const appConfig: AppConfigInterface = {
  ownerRoles: ['Account Manager'],
  customerRoles: [],
  tenantRoles: ['Business Owner', 'Team Member', 'Account Manager', 'Customer Service Representative', 'End Customer'],
  tenantName: 'Company',
  applicationName: 'Raven Management System',
  addOns: ['file upload', 'chat', 'notifications', 'file'],
  customerAbilities: [],
  ownerAbilities: [
    'Manage product purchases',
    'Manage transaction history',
    'Manage customer details',
    'Manage user and company information',
  ],
  getQuoteUrl: 'https://app.roq.ai/proposal/c8e9e54e-8eb1-4995-a89e-9618cdf17677',
};
