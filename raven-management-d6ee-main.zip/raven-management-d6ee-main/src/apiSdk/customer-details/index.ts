import queryString from 'query-string';
import { CustomerDetailsInterface, CustomerDetailsGetQueryInterface } from 'interfaces/customer-details';
import { fetcher } from 'lib/api-fetcher';
import { GetQueryInterface, PaginatedInterface } from '../../interfaces';

export const getCustomerDetails = async (
  query?: CustomerDetailsGetQueryInterface,
): Promise<PaginatedInterface<CustomerDetailsInterface>> => {
  return fetcher('/api/customer-details', {}, query);
};

export const createCustomerDetails = async (customerDetails: CustomerDetailsInterface) => {
  return fetcher('/api/customer-details', { method: 'POST', body: JSON.stringify(customerDetails) });
};

export const updateCustomerDetailsById = async (id: string, customerDetails: CustomerDetailsInterface) => {
  return fetcher(`/api/customer-details/${id}`, { method: 'PUT', body: JSON.stringify(customerDetails) });
};

export const getCustomerDetailsById = async (id: string, query?: GetQueryInterface) => {
  return fetcher(`/api/customer-details/${id}${query ? `?${queryString.stringify(query)}` : ''}`, {});
};

export const deleteCustomerDetailsById = async (id: string) => {
  return fetcher(`/api/customer-details/${id}`, { method: 'DELETE' });
};
