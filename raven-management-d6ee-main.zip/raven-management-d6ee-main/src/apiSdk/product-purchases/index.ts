import queryString from 'query-string';
import { ProductPurchasesInterface, ProductPurchasesGetQueryInterface } from 'interfaces/product-purchases';
import { fetcher } from 'lib/api-fetcher';
import { GetQueryInterface, PaginatedInterface } from '../../interfaces';

export const getProductPurchases = async (
  query?: ProductPurchasesGetQueryInterface,
): Promise<PaginatedInterface<ProductPurchasesInterface>> => {
  return fetcher('/api/product-purchases', {}, query);
};

export const createProductPurchases = async (productPurchases: ProductPurchasesInterface) => {
  return fetcher('/api/product-purchases', { method: 'POST', body: JSON.stringify(productPurchases) });
};

export const updateProductPurchasesById = async (id: string, productPurchases: ProductPurchasesInterface) => {
  return fetcher(`/api/product-purchases/${id}`, { method: 'PUT', body: JSON.stringify(productPurchases) });
};

export const getProductPurchasesById = async (id: string, query?: GetQueryInterface) => {
  return fetcher(`/api/product-purchases/${id}${query ? `?${queryString.stringify(query)}` : ''}`, {});
};

export const deleteProductPurchasesById = async (id: string) => {
  return fetcher(`/api/product-purchases/${id}`, { method: 'DELETE' });
};
