-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
