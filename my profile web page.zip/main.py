import eel
  
eel.init("web")  
  
eel.start("home.html")