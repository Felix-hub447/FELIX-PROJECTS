<?php
$host = "localhost";
$username = "root";
$password = "password";
$database ="";

// Create connection
$conn = new mysqli($localhost, $root, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?> 